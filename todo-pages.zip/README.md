# 拾光清单 · GitHub Pages 静态版

这个文件夹只包含**不需要 Node 的离线静态版**，适合直接上传到 GitHub Pages。

## 上传

1. 在 GitHub 新建仓库。
2. 把本文件夹里的全部内容上传到仓库**根目录**：
   - `index.html`
   - `detail.html`
   - `assets/`
   - `data/`
   - `.nojekyll`
3. 进入仓库 **Settings → Pages**。
4. **Build and deployment → Source** 选 **Deploy from a branch**。
5. 分支选 `main`，目录选 `/ (root)`，保存。
6. 等 Actions 部署完成，打开：
   `https://<你的用户名>.github.io/<仓库名>/`

## 说明

- 列表、详情、筛选、新建、编辑、删除都能用。
- 数据存在浏览器的 `localStorage`，不上传服务器；换浏览器/换设备不会同步。
- 首次加载会 `fetch` 一次 `data/tasks.json` 作为示例数据，之后以本地修改为准。
- 这个包**没有 API 页**，因为 GitHub Pages 只能托管静态文件，不能运行 Express/SQLite。
- 如果要在线 API 页，请把完整项目部署到 Render / Railway / 云服务器，或让 GitHub Pages 只做前端、API 单独部署，并在 `runtime-config.js` 填写 API 地址、在服务端设置 `CORS_ORIGIN`。

完整说明见项目根目录的 `README.md`。
