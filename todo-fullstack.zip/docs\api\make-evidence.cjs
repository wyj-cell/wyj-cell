'use strict';

/**
 * 把实际 curl 输出整理成两份「成绩单」：
 * 1. 三个接口成功调用；
 * 2. 少传 title 返回 400。
 *
 * 这里不重新请求接口，只读取 docs/raw 下的真实响应，
 * 避免截图内容和实际返回不一致。
 */

const fs = require('node:fs');
const path = require('node:path');

const RAW_DIR = path.join(__dirname, 'raw');
const BASE_URL = 'http://127.0.0.1:3000';

const successCalls = [
  {
    command: `curl.exe -s -i -X POST ${BASE_URL}/api/todos -H "Content-Type: application/json" --data-binary "@docs/body-create.json"`,
    file: 'post1.txt'
  },
  {
    command: `curl.exe -s -i ${BASE_URL}/api/todos`,
    file: 'get1.txt'
  },
  {
    command: `curl.exe -s -i -X DELETE ${BASE_URL}/api/todos/1`,
    file: 'delete1.txt'
  },
  {
    command: `curl.exe -s -i ${BASE_URL}/api/todos`,
    file: 'get2.txt'
  }
];

const badCalls = [
  {
    command: `curl.exe -s -i -X POST ${BASE_URL}/api/todos -H "Content-Type: application/json" --data-binary "@docs/body-bad.json"`,
    file: 'bad.txt'
  }
];

function readRaw(file) {
  return fs.readFileSync(path.join(RAW_DIR, file), 'utf8').trimEnd();
}

function buildTranscript(calls) {
  return calls
    .map((call) => `$ ${call.command}\n${readRaw(call.file)}`)
    .join('\n\n');
}

function escapeHtml(value) {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;');
}

function renderTerminal(text) {
  return text
    .split('\n')
    .map((line) => {
      const safe = escapeHtml(line);
      if (line.startsWith('$ ')) return `<span class="cmd">${safe}</span>`;
      if (/^HTTP\/1\.1 2\d\d/.test(line)) return `<span class="ok">${safe}</span>`;
      if (/^HTTP\/1\.1 4\d\d/.test(line)) return `<span class="err">${safe}</span>`;
      return safe;
    })
    .join('\n');
}

const styles = `
  :root {
    --paper: #ece7dc;
    --ink: #20241f;
    --panel: #11140f;
    --panel-2: #1a1e17;
    --line: #30372c;
    --text: #dbe4d1;
    --muted: #9ea694;
    --amber: #e8bd78;
    --green: #9ccf89;
    --red: #f08b73;
  }
  * { box-sizing: border-box; }
  body {
    margin: 0;
    background: radial-gradient(circle at 12% 0%, #f7f1e5 0, var(--paper) 42%, #ded7c9 100%);
    color: var(--ink);
    font-family: "Microsoft YaHei UI", "PingFang SC", "Noto Sans CJK SC", sans-serif;
  }
  .page { width: 1260px; margin: 42px auto 50px; }
  .meta { display: flex; align-items: end; justify-content: space-between; gap: 24px; margin-bottom: 22px; }
  .kicker { color: #a24b2f; font-size: 12px; font-weight: 700; letter-spacing: .22em; }
  h1 { margin: 8px 0 0; font-family: Georgia, "Songti SC", serif; font-size: 46px; font-weight: 500; letter-spacing: -.04em; }
  .stamp { color: #6f7468; font-size: 12px; line-height: 1.9; text-align: right; white-space: nowrap; }
  .chips { display: flex; flex-wrap: wrap; gap: 8px; margin: 0 0 22px; }
  .chip { border: 1px solid #c9c0ae; border-radius: 999px; padding: 6px 11px; font-size: 11px; font-weight: 700; letter-spacing: .08em; background: #f6f0e4; }
  .chip.ok { color: #3c6f39; border-color: #a9c49d; }
  .chip.err { color: #9a3d2a; border-color: #d5a393; }
  .terminal {
    overflow: hidden;
    border: 1px solid #2b3127;
    border-radius: 18px;
    background: var(--panel);
    box-shadow: 0 24px 60px rgba(42, 36, 26, .18);
  }
  .bar { display: flex; align-items: center; gap: 9px; padding: 14px 18px; background: var(--panel-2); border-bottom: 1px solid var(--line); }
  .dot { width: 10px; height: 10px; border-radius: 50%; background: #4f5748; }
  .dot:nth-child(1) { background: #c76b54; }
  .dot:nth-child(2) { background: #c9a35b; }
  .dot:nth-child(3) { background: #739268; }
  .bar strong { margin-left: 8px; color: #c7cfbd; font-size: 11px; font-weight: 500; letter-spacing: .1em; }
  pre {
    margin: 0;
    padding: 24px 28px 28px;
    color: var(--text);
    font-family: "Cascadia Mono", "Consolas", "Noto Sans Mono CJK SC", monospace;
    font-size: 13.2px;
    line-height: 1.66;
    white-space: pre-wrap;
    word-break: break-word;
  }
  .cmd { color: var(--amber); font-weight: 700; }
  .ok { color: var(--green); font-weight: 700; }
  .err { color: var(--red); font-weight: 700; }
  .note { margin: 0 0 18px; padding: 15px 18px; border-left: 4px solid #b94c2d; background: #f7efe2; color: #5a4034; font-size: 13px; line-height: 1.8; }
  .note code { background: #eadfce; padding: 1px 5px; border-radius: 4px; }
  .foot { margin-top: 18px; color: #777b6e; font-size: 11px; line-height: 1.8; }
`;

function renderPage({ title, kicker, chips, note, transcript }) {
  return `<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${escapeHtml(title)}</title>
<style>${styles}</style>
</head>
<body>
<main class="page">
  <header class="meta">
    <section>
      <p class="kicker">${escapeHtml(kicker)}</p>
      <h1>${escapeHtml(title)}</h1>
    </section>
    <p class="stamp">Todo API · Node.js + Express + SQLite<br>http://127.0.0.1:3000</p>
  </header>
  <nav class="chips" aria-label="验收结果">
    ${chips.map((chip) => `<span class="chip ${chip.tone || ''}">${escapeHtml(chip.label)}</span>`).join('\n    ')}
  </nav>
  ${note ? `<p class="note">${note}</p>` : ''}
  <section class="terminal" aria-label="curl 输出">
    <header class="bar"><i class="dot"></i><i class="dot"></i><i class="dot"></i><strong>curl · actual output</strong></header>
    <pre>${renderTerminal(transcript)}</pre>
  </section>
  <p class="foot">说明：以上为实际 curl 响应，状态行和 JSON 均未改写；截图仅把输出整理成终端样式。</p>
</main>
</body>
</html>`;
}

function write(file, content) {
  fs.writeFileSync(path.join(__dirname, file), content, 'utf8');
}

const successTranscript = buildTranscript(successCalls);
const badTranscript = buildTranscript(badCalls);

write('curl-success.txt', successTranscript + '\n');
write('curl-400.txt', badTranscript + '\n');

write(
  'evidence-success.html',
  renderPage({
    title: '三个接口 · 验收记录',
    kicker: 'API ACCEPTANCE / 01',
    chips: [
      { label: 'POST /api/todos · 201', tone: 'ok' },
      { label: 'GET /api/todos · 200', tone: 'ok' },
      { label: 'DELETE /api/todos/1 · 200', tone: 'ok' },
      { label: '返回格式统一', tone: '' }
    ],
    note: '三个接口依次调通：先新增、再查询、再删除，最后再查一次确认删除生效。',
    transcript: successTranscript
  })
);

write(
  'evidence-400.html',
  renderPage({
    title: '少传字段 · 400 验收',
    kicker: 'API ACCEPTANCE / 02',
    chips: [
      { label: 'POST /api/todos · 400', tone: 'err' },
      { label: '不是 500', tone: 'err' },
      { label: 'data 为 null', tone: '' }
    ],
    note: '请求体只有 <code>{"done":true}</code>，故意不传 <code>title</code>。服务端在进入数据库前就校验并拦截，返回 HTTP 400 + JSON，而不是 500。',
    transcript: badTranscript
  })
);

console.log('已生成 curl-success.txt、curl-400.txt 和两份 evidence HTML。');
