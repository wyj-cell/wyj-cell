'use strict';

/**
 * 接口回归测试：不依赖 Postman，直接用 Node 18+ 自带的 fetch 调本地服务。
 * 重点覆盖：统一响应格式、400 校验、404、删除、以及重启后数据仍在。
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const { openStore } = require('../src/db');
const { createApp } = require('../src/app');

const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'todo-api-test-'));
const dbFile = path.join(tempDir, 'todos.db');

let store;
let server;
let baseUrl;
let createdId;

async function request(method, pathname, body, headers = {}) {
  const options = { method, headers: { ...headers } };
  if (body !== undefined) {
    options.headers['content-type'] = 'application/json';
    options.body = typeof body === 'string' ? body : JSON.stringify(body);
  }
  const response = await fetch(baseUrl + pathname, options);
  const payload = await response.json();
  return { response, payload };
}

test.before(async () => {
  store = await openStore({ file: dbFile });
  const app = createApp(store);
  await new Promise((resolve) => {
    server = app.listen(0, '127.0.0.1', resolve);
  });
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});

test.after(async () => {
  if (server) {
    await new Promise((resolve) => server.close(resolve));
  }
  if (store) store.close();
  fs.rmSync(tempDir, { recursive: true, force: true });
});

test('GET /api/todos 空列表也返回统一对象', async () => {
  const { response, payload } = await request('GET', '/api/todos');
  assert.equal(response.status, 200);
  assert.deepEqual(payload, {
    code: 0,
    data: { list: [], total: 0 },
    msg: '查询成功'
  });
});

test('POST /api/todos 少传 title 返回 400，不是 500', async () => {
  const { response, payload } = await request('POST', '/api/todos', { done: true });
  assert.equal(response.status, 400);
  assert.equal(payload.code, 400);
  assert.equal(payload.data, null);
  assert.match(payload.msg, /title/);
});

test('POST /api/todos done 类型错误返回 400', async () => {
  const { response, payload } = await request('POST', '/api/todos', {
    title: '测试',
    done: 'yes'
  });
  assert.equal(response.status, 400);
  assert.equal(payload.code, 400);
});

test('POST /api/todos 创建成功并返回对象', async () => {
  const { response, payload } = await request('POST', '/api/todos', {
    title: '  写完接口文档  ',
    done: false
  });
  assert.equal(response.status, 201);
  assert.equal(payload.code, 0);
  assert.equal(payload.data.title, '写完接口文档');
  assert.equal(payload.data.done, false);
  assert.match(payload.data.createdAt, /^\d{4}-\d{2}-\d{2}T/);
  createdId = payload.data.id;
});

test('GET /api/todos 能拿到刚创建的数据', async () => {
  const { response, payload } = await request('GET', '/api/todos');
  assert.equal(response.status, 200);
  assert.equal(payload.data.total, 1);
  assert.equal(payload.data.list[0].id, createdId);
});

test('DELETE /api/todos/:id 参数不是正整数返回 400', async () => {
  const { response, payload } = await request('DELETE', '/api/todos/abc');
  assert.equal(response.status, 400);
  assert.equal(payload.code, 400);
});

test('DELETE /api/todos/:id 不存在返回 404', async () => {
  const { response, payload } = await request('DELETE', '/api/todos/999');
  assert.equal(response.status, 404);
  assert.equal(payload.code, 404);
});

test('DELETE /api/todos/:id 删除成功', async () => {
  const { response, payload } = await request('DELETE', `/api/todos/${createdId}`);
  assert.equal(response.status, 200);
  assert.deepEqual(payload, {
    code: 0,
    data: { id: createdId },
    msg: '删除成功'
  });

  const list = await request('GET', '/api/todos');
  assert.equal(list.payload.data.total, 0);
});

test('非法 JSON 返回 400 JSON，而不是 Express 的 HTML 错误页', async () => {
  const { response, payload } = await request(
    'POST',
    '/api/todos',
    '{"title": "坏掉的 JSON"',
    { 'content-type': 'application/json' }
  );
  assert.equal(response.status, 400);
  assert.equal(payload.code, 400);
  assert.match(payload.msg, /JSON/);
});

test('不存在的路由返回 404 JSON', async () => {
  const { response, payload } = await request('GET', '/api/not-exists');
  assert.equal(response.status, 404);
  assert.deepEqual(payload, {
    code: 404,
    data: null,
    msg: '接口不存在'
  });
});

test('未处理异常返回 500 JSON，不返回 HTML 报错栈', async () => {
  const failingStore = {
    listTodos() {
      throw new Error('模拟数据库异常');
    }
  };
  const failingApp = createApp(failingStore);
  const failingServer = await new Promise((resolve) => {
    const instance = failingApp.listen(0, '127.0.0.1', () => resolve(instance));
  });

  // 测试时不要真的把堆栈打印到终端，只验证响应格式。
  const originalError = console.error;
  console.error = () => {};
  try {
    const response = await fetch(
      `http://127.0.0.1:${failingServer.address().port}/api/todos`
    );
    assert.equal(response.status, 500);
    assert.match(response.headers.get('content-type'), /application\/json/);
    assert.deepEqual(await response.json(), {
      code: 500,
      data: null,
      msg: '服务器内部错误'
    });
  } finally {
    console.error = originalError;
    await new Promise((resolve) => failingServer.close(resolve));
  }
});

test('关掉数据库再打开，之前的数据还在', async () => {
  const persistFile = path.join(tempDir, 'persist.db');

  const first = await openStore({ file: persistFile });
  first.createTodo({ title: '重启后还要看到我', done: true });
  first.close();

  const second = await openStore({ file: persistFile });
  const list = second.listTodos();
  second.close();

  assert.equal(list.length, 1);
  assert.equal(list[0].title, '重启后还要看到我');
  assert.equal(list[0].done, true);
});
