'use strict';

/**
 * 启动入口：打开 SQLite、创建 Express 应用、监听端口。
 * 关闭服务时先停止接收请求，再把数据库安全写盘。
 */

const path = require('node:path');
const { openStore } = require('./db');
const { createApp } = require('./app');

const PORT = Number(process.env.PORT) || 3000;
const HOST = process.env.HOST || '127.0.0.1';
const STATIC_DIR = path.join(__dirname, '..');

async function start() {
  const store = await openStore();
  const app = createApp(store, { staticDir: STATIC_DIR });

  const server = app.listen(PORT, HOST, () => {
    console.log(`拾光清单已启动: http://${HOST}:${PORT}/`);
    console.log(`API 演示页: http://${HOST}:${PORT}/api.html`);
    console.log(`待办接口: http://${HOST}:${PORT}/api/todos`);
    console.log(`数据库文件: ${store.file}`);
  });

  server.on('error', (error) => {
    console.error('[server] 启动失败:', error.message);
    store.close();
    process.exitCode = 1;
  });

  let closing = false;
  function shutdown(signal) {
    if (closing) return;
    closing = true;
    console.log(`\n收到 ${signal}，正在关闭服务...`);

    const force = setTimeout(() => process.exit(1), 5000);
    force.unref();

    server.close(() => {
      try {
        store.close();
        console.log('数据库已保存，服务已退出。');
        process.exit(0);
      } catch (error) {
        console.error('[server] 关闭数据库失败:', error.message);
        process.exit(1);
      }
    });
  }

  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));
}

start().catch((error) => {
  console.error('[server] 初始化失败:', error);
  process.exit(1);
});
