'use strict';

/**
 * 数据层：SQLite（sql.js 是 SQLite 官方 C 代码编译出的 WebAssembly 版本）。
 *
 * 为什么用 sql.js：
 * - Node 18+ 直接可运行，不需要在 Windows 上安装 C++ 编译工具；
 * - 数据库仍然是标准 SQLite，写出的 data/todos.db 可以用 SQLite 工具打开；
 * - 每次新增/删除后调用 db.export() 写回磁盘，保证关掉服务再启动数据还在。
 */

const fs = require('node:fs');
const path = require('node:path');
const initSqlJs = require('sql.js');

const DEFAULT_DB_FILE = path.join(__dirname, '..', 'data', 'todos.db');
const SQL_WASM_DIR = path.join(__dirname, '..', 'node_modules', 'sql.js', 'dist');

const SCHEMA = `
  CREATE TABLE IF NOT EXISTS todos (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    title      TEXT    NOT NULL,
    done       INTEGER NOT NULL DEFAULT 0 CHECK (done IN (0, 1)),
    created_at TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
  );
`;

/**
 * 把查询结果转换成普通对象。
 * done 在 SQLite 里是 0/1，这里统一转成 boolean，接口返回更自然。
 */
function rowToTodo(row) {
  return {
    id: Number(row.id),
    title: String(row.title),
    done: Boolean(row.done),
    createdAt: String(row.createdAt)
  };
}

/**
 * 打开数据库，并在需要时自动建表。
 * 通过 options.file 可以指定测试用的临时数据库。
 */
async function openStore(options = {}) {
  const file = path.resolve(options.file || process.env.DB_FILE || DEFAULT_DB_FILE);

  // 显式指定 wasm 文件位置，避免打包/换目录后找不到 sql-wasm.wasm。
  const SQL = await initSqlJs({
    locateFile: (name) => path.join(SQL_WASM_DIR, name)
  });

  fs.mkdirSync(path.dirname(file), { recursive: true });

  let db;
  if (fs.existsSync(file) && fs.statSync(file).size > 0) {
    db = new SQL.Database(fs.readFileSync(file));
  } else {
    db = new SQL.Database();
  }

  db.run(SCHEMA);

  // 原子写盘：先写 .tmp，再替换正式文件。
  // Windows 上 rename 覆盖旧文件可能被拒绝，所以保留 copyFile 作为兜底。
  function persist() {
    const bytes = Buffer.from(db.export());
    const tmp = `${file}.tmp`;
    fs.writeFileSync(tmp, bytes);
    try {
      fs.renameSync(tmp, file);
    } catch (error) {
      fs.copyFileSync(tmp, file);
      fs.unlinkSync(tmp);
    }
  }

  // 首次启动立刻落盘，确保 data/todos.db 存在。
  persist();

  function getTodo(id) {
    const statement = db.prepare(
      'SELECT id, title, done, created_at AS createdAt FROM todos WHERE id = ?'
    );
    try {
      statement.bind([id]);
      if (!statement.step()) return null;
      return rowToTodo(statement.getAsObject());
    } finally {
      statement.free();
    }
  }

  function listTodos() {
    const result = db.exec(
      'SELECT id, title, done, created_at AS createdAt FROM todos ORDER BY id DESC'
    );
    if (!result.length) return [];
    const { columns, values } = result[0];
    return values.map((value) =>
      rowToTodo(Object.fromEntries(columns.map((column, index) => [column, value[index]])))
    );
  }

  function createTodo({ title, done }) {
    db.run('INSERT INTO todos (title, done) VALUES (?, ?)', [title, done ? 1 : 0]);
    const id = Number(db.exec('SELECT last_insert_rowid() AS id')[0].values[0][0]);
    persist();
    return getTodo(id);
  }

  function deleteTodo(id) {
    const existing = getTodo(id);
    if (!existing) return null;
    db.run('DELETE FROM todos WHERE id = ?', [id]);
    persist();
    return existing;
  }

  function close() {
    persist();
    db.close();
  }

  return {
    file,
    listTodos,
    getTodo,
    createTodo,
    deleteTodo,
    close
  };
}

module.exports = { openStore };
