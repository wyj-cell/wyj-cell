/* ==========================================================================
   拾光清单 · api.js
   SQLite 在线版的全部前端行为：读取列表、写一条、删一条、错误提示与确认弹层。
   只使用原生 fetch / DOM API，所有用户文本都通过 textContent 写入。
   ========================================================================== */

(() => {
  "use strict";

  const API_URL = "./api/todos";

  // 页面元素集中取一次，避免在事件回调里反复查询 DOM。
  const elements = {
    form: document.querySelector("#api-form"),
    titleInput: document.querySelector("#api-title-input"),
    submit: document.querySelector("#api-submit"),
    formError: document.querySelector("#api-form-error"),
    list: document.querySelector("#api-list"),
    count: document.querySelector("#api-count"),
    loading: document.querySelector("#api-loading"),
    empty: document.querySelector("#api-empty"),
    emptyCreate: document.querySelector("#api-empty-create"),
    error: document.querySelector("#api-error"),
    errorMessage: document.querySelector("#api-error-message"),
    retry: document.querySelector("#api-retry"),
    total: document.querySelector("#api-total"),
    done: document.querySelector("#api-done"),
    pending: document.querySelector("#api-pending"),
    status: document.querySelector("#api-status"),
    statusText: document.querySelector("#api-status-text"),
    section: document.querySelector("#api-list-section"),
    deleteDialog: document.querySelector("#api-delete-dialog"),
    deleteText: document.querySelector("#api-delete-text"),
    deleteCancel: document.querySelector("#api-delete-cancel"),
    deleteConfirm: document.querySelector("#api-delete-confirm"),
    toast: document.querySelector("#api-toast")
  };

  const state = {
    items: [],
    deleting: null,
    toastTimer: null
  };

  init();

  function init() {
    elements.form.addEventListener("submit", handleCreate);
    elements.list.addEventListener("click", handleListClick);
    elements.retry.addEventListener("click", loadTodos);
    elements.emptyCreate.addEventListener("click", () => elements.titleInput.focus());
    elements.deleteCancel.addEventListener("click", () => elements.deleteDialog.close());
    elements.deleteConfirm.addEventListener("click", confirmDelete);
    elements.deleteDialog.addEventListener("click", (event) => {
      if (event.target === elements.deleteDialog) elements.deleteDialog.close();
    });

    loadTodos();
  }
  // 职责：集中绑定表单、删除确认和重试事件，并触发第一次读取。

  /**
   * 统一的接口请求：无论成功失败都以 { code, data, msg } 解析。
   * 网络断开、返回 HTML、HTTP 非 2xx、业务 code 非 0 都会抛出一句人话。
   */
  async function request(path, options = {}) {
    let response;
    try {
      response = await fetch(path, {
        ...options,
        headers: {
          Accept: "application/json",
          ...(options.headers || {})
        }
      });
    } catch {
      throw new Error("无法连接接口，请确认 Node 服务正在运行。");
    }

    let payload;
    try {
      payload = await response.json();
    } catch {
      throw new Error(`接口返回了非 JSON 内容（HTTP ${response.status}）。`);
    }

    if (!response.ok || !payload || payload.code !== 0) {
      throw new Error(payload && payload.msg ? payload.msg : `请求失败（HTTP ${response.status}）。`);
    }

    return payload.data;
  }
  // 职责：把 fetch、HTTP 状态、JSON 解析和业务错误码收在一个函数里。

  async function loadTodos() {
    elements.section.setAttribute("aria-busy", "true");
    elements.loading.hidden = false;
    elements.empty.hidden = true;
    elements.error.hidden = true;
    elements.list.hidden = false;
    setStatus("正在连接 SQLite…", false);

    try {
      const data = await request(API_URL);
      state.items = Array.isArray(data.list) ? data.list : [];
      render();
      setStatus("已连接 · 数据来自 SQLite", false);
    } catch (error) {
      showLoadError(error.message);
      setStatus("连接失败", true);
    } finally {
      elements.section.setAttribute("aria-busy", "false");
    }
  }
  // 职责：读取 GET /api/todos，成功渲染列表，失败显示可重试的错误态。

  function render() {
    elements.loading.hidden = true;
    elements.error.hidden = true;
    elements.list.replaceChildren(...state.items.map(createItem));

    const total = state.items.length;
    const done = state.items.filter((item) => item.done).length;
    elements.total.textContent = String(total);
    elements.done.textContent = String(done);
    elements.pending.textContent = String(total - done);
    elements.count.textContent = `共 ${total} 件 · 来自 SQLite`;
    elements.list.hidden = total === 0;
    elements.empty.hidden = total !== 0;
    elements.section.setAttribute("aria-busy", "false");
  }
  // 职责：把任务数组变成语义化列表，并同步统计数字、空状态和 aria-busy。

  function createItem(item) {
    const row = document.createElement("li");
    row.className = "api-item";

    const card = document.createElement("article");
    card.className = "api-item__card";

    const top = document.createElement("header");
    top.className = "api-item__top";

    const id = document.createElement("span");
    id.className = "api-item__id";
    id.textContent = `#${String(item.id).padStart(2, "0")}`;

    const status = document.createElement("span");
    status.className = `status-pill ${item.done ? "status-pill--done" : "status-pill--todo"}`;
    status.textContent = item.done ? "已完成" : "待完成";
    top.append(id, status);

    const title = document.createElement("h3");
    title.className = "api-item__title";
    title.textContent = item.title;

    const meta = document.createElement("p");
    meta.className = "api-item__meta";
    meta.textContent = `创建于 ${formatCreated(item.createdAt)}`;

    const foot = document.createElement("footer");
    foot.className = "api-item__foot";

    const source = document.createElement("span");
    source.className = "api-item__source";
    source.textContent = `SQLite · id ${item.id}`;

    const remove = document.createElement("button");
    remove.className = "button button--danger button--small api-item__delete";
    remove.type = "button";
    remove.dataset.delete = String(item.id);
    remove.setAttribute("aria-label", `删除「${item.title}」`);
    remove.textContent = "删除";

    foot.append(source, remove);
    card.append(top, title, meta, foot);
    row.append(card);
    return row;
  }
  // 职责：单条任务的 DOM 构造；标题、时间、aria-label 全部走 textContent / setAttribute。

  function formatCreated(value) {
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return "时间未知";
    return new Intl.DateTimeFormat("zh-CN", {
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    }).format(date);
  }
  // 职责：把接口返回的 ISO 时间换成本地可读文案。

  async function handleCreate(event) {
    event.preventDefault();
    hideFormError();

    const title = elements.titleInput.value.trim();
    if (!title) {
      showFormError("请先写下标题。");
      elements.titleInput.focus();
      return;
    }
    if (title.length > 100) {
      showFormError("标题不能超过 100 个字符。");
      elements.titleInput.focus();
      return;
    }

    elements.submit.disabled = true;
    elements.submit.textContent = "保存中…";

    try {
      const created = await request(API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title })
      });
      state.items.unshift(created);
      elements.form.reset();
      render();
      elements.titleInput.focus();
      showToast(`已加入「${created.title}」`);
    } catch (error) {
      showFormError(error.message);
    } finally {
      elements.submit.disabled = false;
      elements.submit.textContent = "加入清单";
    }
  }
  // 职责：POST 新增；先做本地空值/长度校验，再交给服务端做最终校验。

  function handleListClick(event) {
    const button = event.target.closest("[data-delete]");
    if (!button) return;

    const id = Number(button.dataset.delete);
    const item = state.items.find((entry) => entry.id === id);
    if (!item) return;

    state.deleting = item;
    elements.deleteText.textContent = `#${String(id).padStart(2, "0")}「${item.title}」将从 SQLite 中移除，此操作不可撤销。`;
    elements.deleteDialog.showModal();
    elements.deleteCancel.focus();
  }
  // 职责：点击删除时先打开原生 dialog 确认，不直接发请求。

  async function confirmDelete() {
    const item = state.deleting;
    if (!item) return;

    elements.deleteConfirm.disabled = true;
    elements.deleteConfirm.textContent = "删除中…";

    try {
      await request(`${API_URL}/${item.id}`, { method: "DELETE" });
      state.items = state.items.filter((entry) => entry.id !== item.id);
      elements.deleteDialog.close();
      render();
      showToast(`已删除「${item.title}」`);
    } catch (error) {
      elements.deleteDialog.close();
      showToast(`删除失败：${error.message}`);
    } finally {
      state.deleting = null;
      elements.deleteConfirm.disabled = false;
      elements.deleteConfirm.textContent = "确认删除";
    }
  }
  // 职责：DELETE 成功后从本地数组移除并重绘；失败则关闭确认框并提示原因。

  function showLoadError(message) {
    elements.loading.hidden = true;
    elements.list.hidden = true;
    elements.empty.hidden = true;
    elements.error.hidden = false;
    elements.errorMessage.textContent = message;
  }
  // 职责：列表读取失败时显示错误原因和“再试一次”，不留下空白页。

  function setStatus(message, isError) {
    elements.statusText.textContent = message;
    elements.status.classList.toggle("is-error", Boolean(isError));
  }
  // 职责：右上角状态文案与圆点颜色同步。

  function showFormError(message) {
    elements.formError.textContent = message;
    elements.formError.hidden = false;
  }

  function hideFormError() {
    elements.formError.hidden = true;
    elements.formError.textContent = "";
  }

  function showToast(message) {
    window.clearTimeout(state.toastTimer);
    elements.toast.textContent = message;
    elements.toast.hidden = false;
    requestAnimationFrame(() => elements.toast.classList.add("is-visible"));

    state.toastTimer = window.setTimeout(() => {
      elements.toast.classList.remove("is-visible");
      window.setTimeout(() => {
        elements.toast.hidden = true;
      }, 220);
    }, 3200);
  }
  // 职责：底部轻提示；复用全站 toast 样式，3.2 秒后淡出。
})();
