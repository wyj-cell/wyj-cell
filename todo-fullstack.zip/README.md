# 拾光清单 · Daymark

一个项目，两种运行方式：

- **离线静态版**：`index.html` / `detail.html`，纯原生 HTML、CSS、JavaScript，数据读写浏览器 `localStorage`，可以部署到 GitHub Pages。
- **SQLite 在线版**：`api.html`，页面通过 `GET` / `POST` / `DELETE` 三个接口读写 Express 后面的 SQLite，关掉服务再启动，数据仍在。

两种页面共用同一套设计令牌、按钮、字段和响应式规则；`src/server.js` 同时托管静态页面和 API。另有 `拾光清单-手机单文件版.html`，把样式、脚本和示例数据全部内嵌，适合直接发到手机微信离线打开。

## 快速启动

需要 Node.js 18 或更高版本。

```bash
cd todo-list
npm install          # 如果目录里已有 node_modules，可跳过
npm start            # 等价于 node src/server.js
```

如果环境里没有 npm，也可以直接运行：

```bash
node src/server.js
```

启动后打开：

| 页面 | 地址 | 说明 |
| --- | --- | --- |
| 离线静态版 | <http://127.0.0.1:3000/> | 列表 / 详情 / 筛选 / 本地增删改，不依赖后端 |
| SQLite 在线版 | <http://127.0.0.1:3000/api.html> | 页面直接调用三个接口，数据写入 `data/todos.db` |
| 待办接口 | <http://127.0.0.1:3000/api/todos> | 返回统一 `{ code, data, msg }` |

也可以改端口：

```bash
PORT=4000 node src/server.js
```

Windows PowerShell：

```powershell
$env:PORT=4000; node src/server.js
```

## 接口文档

三个接口都返回同一个外层结构：

```json
{ "code": 0, "data": {}, "msg": "ok" }
```

成功时 `code` 为 `0`；失败时 `code` 与 HTTP 状态一致，`data` 固定为 `null`，`msg` 是可直接展示的中文原因。

| 方法 | 路径 | 参数 | 返回示例 |
| --- | --- | --- | --- |
| `GET` | `/api/todos` | 无 | `{"code":0,"data":{"list":[],"total":0},"msg":"查询成功"}` |
| `POST` | `/api/todos` | `title` 必填，字符串，1–100 字；`done` 可选，boolean，默认 `false` | `{"code":0,"data":{"id":1,"title":"整理接口文档","done":false,"createdAt":"2026-11-14T13:00:13.764Z"},"msg":"创建成功"}` |
| `DELETE` | `/api/todos/:id` | `id` 正整数 | `{"code":0,"data":{"id":1},"msg":"删除成功"}` |

补充约定：

- `POST` 少传 `title`、`title` 不是字符串、`title` 为空白或超过 100 字，返回 **HTTP 400**，不是 500。
- `done` 不是 boolean，返回 **HTTP 400**。
- `DELETE` 的 id 不是正整数，返回 **HTTP 400**；任务不存在返回 **HTTP 404**。
- 非法 JSON 返回 **HTTP 400**；请求体超过 16KB 返回 **HTTP 413**。
- 未匹配的路由返回 **HTTP 404 JSON**；未处理异常返回 **HTTP 500 JSON**。
- 任何错误都不会返回 Express 默认 HTML 错误页，也不会把堆栈甩给前端。

### 用 curl 验收

在项目根目录执行（Windows 用 `curl.exe`，避免 PowerShell 的 `curl` 别名）：

```powershell
# 1. 查询列表
curl.exe -s -i http://127.0.0.1:3000/api/todos

# 2. 新增（UTF-8 body 文件，避免中文被 PowerShell 编码破坏）
curl.exe -s -i -X POST http://127.0.0.1:3000/api/todos `
  -H "Content-Type: application/json" `
  --data-binary "@docs/api/body-create.json"

# 3. 删除（把 1 换成上一步返回的 id）
curl.exe -s -i -X DELETE http://127.0.0.1:3000/api/todos/1

# 4. 故意少传 title：应为 400
curl.exe -s -i -X POST http://127.0.0.1:3000/api/todos `
  -H "Content-Type: application/json" `
  --data-binary "@docs/api/body-bad.json"
```

实际验收截图：

![三个接口依次调通](docs/api/01-三个接口成功.png)

![少传字段返回 400，不是 500](docs/api/02-少传字段400.png)

原始输出、HTML 证据与落盘证明都在 `docs/api/`：

- `curl-success.txt`、`curl-400.txt`、`persistence.txt`
- `raw/`：逐条 curl 原始响应
- `evidence-success.html`、`evidence-400.html`：用于截图的终端样式页面
- `make-evidence.cjs`：从真实输出生成证据页，不重新请求接口

### 自动测试

```bash
node test/api.test.js
```

覆盖 12 个用例：空列表、少 `title` 400、`done` 类型错误 400、创建 201、读取、非法 id 400、不存在 404、删除 200（删除后列表为空）、非法 JSON 400、未知路由 404、未处理异常 500、关库重开数据仍在。

## 数据落盘

- SQLite 文件：`data/todos.db`（首次启动自动创建）。
- 每次新增 / 删除后，`src/db.js` 调用 `db.export()` 写出完整数据库：先写 `.tmp`，再原子替换；Windows 替换失败时用 `copyFileSync` 兜底。
- 关闭服务时先停止接收请求，再保存并关闭数据库。
- 想恢复空库：停止服务，删除 `data/todos.db`，重新启动。

验证方式：新增一条 → 停止服务 → 重新 `npm start` → `GET /api/todos` 仍能查到。

## 文件结构

```text
todo-list/
├── index.html                     # 离线静态版列表页
├── detail.html                    # 离线静态版详情页
├── api.html                       # SQLite 在线版：表单、列表、接口文档表
├── 拾光清单-手机单文件版.html      # 单文件离线版：可直接发微信
├── assets/
│   ├── styles.css                 # 全站设计令牌、布局、组件
│   ├── app.js                     # 离线版行为：一次 fetch + 筛选 + 增删改
│   ├── api.css                    # 在线版专用布局
│   └── api.js                     # 在线版行为：GET / POST / DELETE
├── data/
│   ├── tasks.json                 # 离线版示例数据
│   └── todos.db                   # SQLite 数据库（运行时生成）
├── src/
│   ├── server.js                  # 启动入口：静态页 + API + 优雅关闭
│   ├── app.js                     # 路由、校验、统一响应、全局错误处理
│   └── db.js                      # SQLite 建表、查询、增删、落盘
├── test/
│   └── api.test.js                # Node 自带 test runner，12 个接口用例
├── docs/api/                      # 接口验收截图与原始证据
├── package.json
├── pnpm-lock.yaml
├── .nojekyll
└── README.md
```

## 两种页面的数据边界

| | 离线静态版 `/` | SQLite 在线版 `/api.html` |
| --- | --- | --- |
| 数据源 | `data/tasks.json` 作为种子，之后用 `localStorage` | `data/todos.db` |
| 读取 | 页面加载时一次 `fetch('./data/tasks.json')` | `GET /api/todos` |
| 新增 / 改写 / 删除 | 浏览器本地完成 | `POST` / `DELETE`；当前在线版不提供编辑接口 |
| 是否需要 Node | 不需要，静态服务器即可 | 需要 |
| GitHub Pages | 可以 | 不可以（Pages 只托管静态文件） |

两边数据**互不覆盖**：在在线版新增不会改变离线版的 `tasks.json`，在离线版改写也不会写进 SQLite。这样静态版本仍能保持“双击可看、Pages 可部署”，在线版本则用于演示真实接口与落盘。

## 离线静态版：手机 / 微信单文件

如果要把页面**直接发到手机微信**，不要只发 `index.html`：它依赖同目录的 `assets/`、`data/` 和 `detail.html`，单独发过去会只剩无样式骨架，而且 `file://` 下浏览器不允许 `fetch` 本地 JSON。

请发这个文件：

```text
拾光清单-手机单文件版.html
```

它把 CSS、JavaScript、9 条示例数据和详情弹层全部内嵌在一个 HTML 里，双击即可离线打开，筛选、查看详情、新建、编辑、删除仍然可用；修改保存在该手机浏览器的 `localStorage` 中。项目根目录和 `D:\实验室\` 各有一份相同文件。

即使浏览器完全禁用了 JavaScript，单文件版也会显示 9 张只读任务卡和静态统计，而不是空白骨架；筛选、详情和增删改仍需要 JavaScript。

> 如果微信的“文件预览”仍然只显示静态文字或源码，说明它没有执行本地 HTML 的脚本。请点右上角“用其他应用打开”选手机浏览器，或把静态版部署到 GitHub Pages 后直接发链接。

## 部署静态版到 GitHub Pages

API 页需要 Node 运行环境，不能直接放 GitHub Pages。只部署离线静态版时：

1. 新建仓库，把 `index.html`、`detail.html`、`assets/styles.css`、`assets/app.js`、`data/tasks.json`、`.nojekyll` 上传到仓库根目录。
2. 进入 **Settings → Pages**，选择 **Deploy from a branch**。
3. 分支 `main`，目录 `/ (root)`，保存。
4. 访问 `https://<用户名>.github.io/<仓库名>/`。

如果要把 `api.html` 的接口也放到线上，需要部署到支持 Node 的托管平台（Render、Railway、Fly.io 等），并保证 `data/` 目录可写；纯静态 Pages 只能托管前端文件。

## 离线静态版功能

- 状态筛选：全部 / 待开始 / 进行中 / 已完成，带数量统计。
- 关键词搜索：标题、摘要、分类、负责人、标签。
- 优先级筛选与四种排序；筛选条件同步到 URL。
- 列表页与详情页共用同一份数据。
- 新建、编辑、删除；新建/编辑用原生 `<dialog>` + `<form>`，删除用自定义确认框。
- 清单与步骤勾选保存在 `localStorage`；刷新、关标签页再开仍在。
- 空清单、加载失败、无 JavaScript 都有独立提示。
- 全部使用语义化标签，页面结构中没有 `div`；响应式适配桌面 / 平板 / 手机。
- 支持键盘操作、可见焦点、`prefers-reduced-motion` 与打印样式。

### 恢复离线版示例数据

F12 → **Application / 应用** → **Local Storage**，删除 `daymark:tasks:v1`，刷新。或在 Console：

```js
localStorage.removeItem("daymark:tasks:v1");
location.reload();
```

步骤勾选的键是 `daymark:checklist:<任务 id>`，需要时可一并删除。

## 按 F12 验证

### 离线静态版 `/`

| 要找的内容 | 位置 |
| --- | --- |
| 页面主文档 | `index.html`（详情页为 `detail.html`） |
| 一个 CSS / JS | `assets/styles.css`、`assets/app.js` |
| 一次自己写的 fetch | `data/tasks.json`，Type 为 `fetch`，Initiator 指向 `app.js` |

筛选、排序、搜索、新建、编辑、删除和勾选进度都在浏览器本地完成，不会产生额外请求。

### SQLite 在线版 `/api.html`

| 操作 | Network 里应看到 |
| --- | --- |
| 打开页面 | `api.html`、`styles.css`、`api.css`、`api.js`，以及一次 `GET /api/todos` |
| 新增 | `POST /api/todos`，状态 201 |
| 删除 | `DELETE /api/todos/:id`，状态 200 |

页面只调用这三个接口；所有响应都由 `api.js` 统一解析 `{ code, data, msg }`。

## 实现说明

- **一个进程，两套页面**：`src/server.js` 用 `express.static` 托管项目根目录，同时在 `/api/todos` 挂接口；静态页和 API 同源，不需要 CORS。
- **私有文件隔离**：`src/`、`test/`、`node_modules/`、`docs/`、`package.json`、`pnpm-lock.yaml`、`data/todos.db` 不会被静态服务下载，直接访问返回 404 JSON。
- **统一响应**：`ok()` / `fail()` / `HttpError` 集中在 `src/app.js`；全局错误中间件兜住非法 JSON、超大请求体、未知路由和未处理异常。
- **SQLite 选型**：使用 `sql.js`（SQLite 官方 C 代码的 WebAssembly 版本），Node 18+ 无需 C++ 编译；写出的 `.db` 是标准 SQLite 文件，可用 SQLite 工具打开。
- **防注入**：离线版和在线版的动态文本都用 `textContent` 写入，不使用 `innerHTML` 拼接 JSON 或表单内容。
- **代码注释**：HTML、CSS、JavaScript 按职责分块，每个模块后都有中文说明。

## 测试

```bash
node test/api.test.js
```

当前结果：`12 passed / 0 failed`。浏览器侧另用 Edge headless 验证了离线版 1440 / 1024 / 768 / 390 / 320 无横向溢出，在线版 1440 双列、390 单列，创建 / 删除 / 确认框 / 错误提示正常。
