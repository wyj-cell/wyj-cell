'use strict';

/**
 * HTTP 层：只负责路由、参数校验和统一响应格式，不直接碰 SQLite。
 * 所有成功/失败都返回 { code, data, msg }，前端不需要为不同接口写不同的解析逻辑。
 */

const express = require('express');

// 业务异常：带 HTTP 状态码，交给全局错误处理中间件统一转成 JSON。
class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.name = 'HttpError';
    this.status = status;
  }
}

// 成功响应：code 固定为 0，data 始终是对象（列表放在 data.list 里）。
function ok(data, msg = 'ok') {
  return { code: 0, data, msg };
}

// 失败响应：data 统一为 null，避免前端还要判断 data 是数组还是对象。
function fail(code, msg) {
  return { code, data: null, msg };
}

function normalizeTitle(body) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    throw new HttpError(400, '请求体必须是 JSON 对象');
  }
  if (typeof body.title !== 'string') {
    throw new HttpError(400, 'title 字段必填，且必须是字符串');
  }
  const title = body.title.trim();
  if (!title) {
    throw new HttpError(400, 'title 不能为空');
  }
  if (title.length > 100) {
    throw new HttpError(400, 'title 不能超过 100 个字符');
  }
  return title;
}

function normalizeDone(value) {
  if (value === undefined) return false;
  if (typeof value !== 'boolean') {
    throw new HttpError(400, 'done 必须是 boolean');
  }
  return value;
}

/**
 * 创建 Express 应用。
 * 把 store 作为参数传进来，测试时可以换成临时数据库，不需要改路由代码。
 */
function createApp(store, options = {}) {
  const app = express();
  app.disable('x-powered-by');
  app.use(express.json({ limit: '16kb' }));

  // 私有文件不对外：只暴露静态页面、assets 与 data/tasks.json。
  // 这样把整个项目目录作为静态根时，不会顺带下载数据库、源码、测试或 node_modules。
  const PRIVATE_PREFIX = /^\/(?:src|test|node_modules|docs|pnpm-lock\.yaml|package\.json|\.gitignore)(?:\/|$)/;
  const PRIVATE_DB_FILE = /^\/data\/todos\.db(?:[.-]|$)/;
  app.use((req, res, next) => {
    if (PRIVATE_PREFIX.test(req.path) || PRIVATE_DB_FILE.test(req.path)) {
      return res.status(404).json(fail(404, '资源不存在'));
    }
    next();
  });

  if (options.staticDir) {
    app.use(
      express.static(options.staticDir, {
        index: 'index.html',
        dotfiles: 'deny'
      })
    );
  }

  // GET /api/todos：返回列表；data 是对象，列表在 data.list，数量在 data.total。
  app.get('/api/todos', (req, res, next) => {
    try {
      const list = store.listTodos();
      res.json(ok({ list, total: list.length }, '查询成功'));
    } catch (error) {
      next(error);
    }
  });

  // POST /api/todos：新增；title 必填，done 可选，默认 false。
  app.post('/api/todos', (req, res, next) => {
    try {
      const title = normalizeTitle(req.body);
      const done = normalizeDone(req.body.done);
      const item = store.createTodo({ title, done });
      res.status(201).json(ok(item, '创建成功'));
    } catch (error) {
      next(error);
    }
  });

  // DELETE /api/todos/:id：按 id 删除；id 必须是正整数，找不到返回 404。
  app.delete('/api/todos/:id', (req, res, next) => {
    try {
      if (!/^[1-9]\d*$/.test(req.params.id)) {
        throw new HttpError(400, 'id 必须是正整数');
      }
      const id = Number(req.params.id);
      const deleted = store.deleteTodo(id);
      if (!deleted) {
        throw new HttpError(404, '待办不存在');
      }
      res.json(ok({ id }, '删除成功'));
    } catch (error) {
      next(error);
    }
  });

  // 未匹配到任何路由：不返回 Express 默认 HTML，统一返回 JSON。
  app.use((req, res) => {
    res.status(404).json(fail(404, '接口不存在'));
  });

  // 全局错误处理：任何异常都在这里收口，绝不把 HTML 报错栈甩给前端。
  // 4 个参数是 Express 识别错误中间件的必要条件，next 不能省略。
  app.use((error, req, res, next) => {
    if (res.headersSent) return next(error);

    // JSON 语法错误、请求体过大，属于客户端问题，分别返回 400/413。
    if (error.type === 'entity.parse.failed') {
      return res.status(400).json(fail(400, '请求体必须是合法 JSON'));
    }
    if (error.type === 'entity.too.large') {
      return res.status(413).json(fail(413, '请求体过大'));
    }

    if (error instanceof HttpError) {
      return res.status(error.status).json(fail(error.status, error.message));
    }

    // 真正的服务端异常：只在控制台保留细节，响应只给通用文案。
    console.error('[api] 未处理异常:', error);
    return res.status(500).json(fail(500, '服务器内部错误'));
  });

  return app;
}

module.exports = { createApp, HttpError };
