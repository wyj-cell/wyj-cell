/* ==========================================================================
   拾光清单 · app.js
   原生 JavaScript，无构建步骤、无第三方依赖。
   全站只有 loadTasks() 内部的一次 fetch()。
   ========================================================================== */

(() => {
  "use strict";

  const DATA_URL = "./data/tasks.json";
  const CHECKLIST_PREFIX = "daymark:checklist:";
  const TASKS_STORAGE_KEY = "daymark:tasks:v1";

  const STATUS_META = {
    todo: { label: "待开始", listTitle: "待开始的清单" },
    doing: { label: "进行中", listTitle: "正在进行的清单" },
    done: { label: "已完成", listTitle: "已经完成的清单" }
  };

  const PRIORITY_META = {
    high: { label: "高优先", rank: 0 },
    medium: { label: "中优先", rank: 1 },
    low: { label: "低优先", rank: 2 }
  };

  const SORT_META = {
    due: "截止日期最近",
    priority: "优先级最高",
    updated: "最近更新",
    title: "标题顺序"
  };

  const SORTERS = {
    due: (a, b) =>
      Number(a.status === "done") - Number(b.status === "done") ||
      String(a.due).localeCompare(String(b.due)),
    priority: (a, b) =>
      (PRIORITY_META[a.priority]?.rank ?? 9) - (PRIORITY_META[b.priority]?.rank ?? 9) ||
      String(a.due).localeCompare(String(b.due)),
    updated: (a, b) => String(b.updated).localeCompare(String(a.updated)),
    title: (a, b) => String(a.title).localeCompare(String(b.title), "zh-CN")
  };

  const WEEKDAYS = ["星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"];

  const page = document.body.dataset.page;

  if (page === "list") {
    initListPage();
  }

  if (page === "detail") {
    initDetailPage();
  }

  /* ------------------------------------------------------------------------
     数据请求
     ------------------------------------------------------------------------ */

  /**
   * 页面唯一的一次网络请求：读取本地 JSON。
   * GitHub Pages / 任意静态服务器均可直接工作；直接双击 file:// 打开时会被浏览器的 CORS 策略拦截。
   */
  async function loadTasks() {
    // 单文件离线版会把示例数据直接嵌进 HTML；有它就跳过 fetch，双击 file:// 也能显示。
    if (Array.isArray(window.__DAYMARK_TASKS__)) {
      return window.__DAYMARK_TASKS__;
    }

    const response = await fetch(DATA_URL, {
      headers: { Accept: "application/json" }
    });

    if (!response.ok) {
      throw new Error(`读取任务失败（HTTP ${response.status}）`);
    }

    let payload;

    try {
      payload = await response.json();
    } catch {
      throw new Error("data/tasks.json 不是有效的 JSON 文件");
    }

    if (!payload || !Array.isArray(payload.tasks)) {
      throw new Error("data/tasks.json 缺少 tasks 数组");
    }

    return payload.tasks;
  }
  // 职责：集中处理 fetch、HTTP 错误、JSON 解析与数据结构校验，调用方只关心成功后的任务数组。

  /**
   * 读取页面真正使用的数据：
   * 1. 每次仍只发起一次 fetch，保证 F12 的 Network 中能看到这一次请求；
   * 2. 如果 localStorage 里有用户改过的整份清单，优先使用本地版本；
   * 3. 本地没有记录时，使用 fetch 回来的 JSON 作为初始示例。
   */
  async function loadTaskData() {
    let seeds = [];
    let fetchError = null;

    try {
      seeds = await loadTasks();
    } catch (error) {
      fetchError = error;
    }

    const stored = readStoredTasks();

    if (stored !== null) {
      return stored;
    }

    if (fetchError) {
      throw fetchError;
    }

    return normalizeTasks(seeds);
  }
  // 职责：把“网络示例数据”和“浏览器本地修改”合流；每页只调用一次，因此每页仍只有一次 fetch。

  function readStoredTasks() {
    try {
      const raw = window.localStorage.getItem(TASKS_STORAGE_KEY);

      if (!raw) {
        return null;
      }

      const parsed = JSON.parse(raw);

      if (!parsed || !Array.isArray(parsed.tasks)) {
        return null;
      }

      return normalizeTasks(parsed.tasks);
    } catch {
      return null;
    }
  }
  // 职责：安全读取整份任务数组；没有记录或 JSON 损坏时返回 null，让页面回退到 fetch 的示例数据。

  function normalizeTasks(tasks) {
    const seen = new Set();
    const today = toISODate(new Date());

    return (Array.isArray(tasks) ? tasks : [])
      .filter((task) => task && typeof task === "object")
      .map((task) => {
        const title = String(task.title ?? "").trim() || "未命名待办";
        let id = String(task.id ?? "").trim();

        if (!id) {
          id = createTaskId(title, []);
        }

        if (seen.has(id)) {
          const base = id;
          let suffix = 2;
          while (seen.has(`${base}-${suffix}`)) {
            suffix += 1;
          }
          id = `${base}-${suffix}`;
        }
        seen.add(id);

        const description = (Array.isArray(task.description) ? task.description : [])
          .map((text) => String(text ?? "").trim())
          .filter(Boolean);
        const checklist = (Array.isArray(task.checklist) ? task.checklist : [])
          .map((item) => ({
            text: String(item?.text ?? "").trim(),
            done: Boolean(item?.done)
          }))
          .filter((item) => item.text);
        const tags = (Array.isArray(task.tags) ? task.tags : [])
          .map((tag) => String(tag ?? "").trim())
          .filter(Boolean)
          .slice(0, 4);

        return {
          id,
          title,
          summary: String(task.summary ?? "").trim() || "还没有写摘要。",
          description,
          checklist,
          note: String(task.note ?? "").trim(),
          status: STATUS_META[task.status] ? task.status : "todo",
          priority: PRIORITY_META[task.priority] ? task.priority : "medium",
          category: String(task.category ?? "").trim() || "未分类",
          owner: String(task.owner ?? "").trim() || "我",
          tags,
          due: isISODateString(task.due) ? task.due : "",
          updated: isISODateString(task.updated) ? task.updated : today
        };
      });
  }
  // 职责：把 JSON 或 localStorage 里的任意任务补齐成页面可用的稳定结构，并为缺失/重复的 id 兜底。

  function isISODateString(value) {
    return typeof value === "string" && /^\d{4}-\d{2}-\d{2}$/.test(value);
  }
  // 职责：只接受 YYYY-MM-DD，避免坏日期进入排序和 time[datetime]。

  function createTaskId(title, tasks) {
    const base = String(title ?? "")
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 36);
    let candidate = base || `task-${Date.now().toString(36)}`;
    let suffix = 2;

    while (tasks.some((task) => task && task.id === candidate)) {
      candidate = `${base || "task"}-${suffix}`;
      suffix += 1;
    }

    return candidate;
  }
  // 职责：由标题生成稳定、可放进 URL 的 id；中文标题会退化为时间戳 id，并自动避开已有 id。

  function persistTasks(tasks) {
    try {
      window.localStorage.setItem(
        TASKS_STORAGE_KEY,
        JSON.stringify({ version: 1, tasks })
      );
      return true;
    } catch {
      return false;
    }
  }
  // 职责：把增删改后的整份清单写入 localStorage；返回 false 时由调用方提示“刷新后会恢复”。

  /* ------------------------------------------------------------------------
     列表页
     ------------------------------------------------------------------------ */

  function initListPage() {
    setCurrentYear();
    setTodayLabel();

    const notice = new URLSearchParams(window.location.search).get("notice");
    const elements = {
      form: document.getElementById("filter-form"),
      tabs: Array.from(document.querySelectorAll("#filter-tabs .filter-tab")),
      search: document.getElementById("search-input"),
      priority: document.getElementById("priority-select"),
      sort: document.getElementById("sort-select"),
      reset: document.getElementById("reset-filters"),
      create: document.getElementById("create-task"),
      emptyCreate: document.getElementById("empty-create"),
      emptyReset: document.getElementById("empty-reset"),
      emptyTitle: document.getElementById("empty-title"),
      emptyMessage: document.getElementById("empty-message"),
      retry: document.getElementById("retry-button"),
      resultCount: document.getElementById("result-count"),
      taskSection: document.getElementById("tasks"),
      taskGrid: document.getElementById("task-grid"),
      loadingGrid: document.getElementById("loading-grid"),
      listTitle: document.getElementById("task-list-title"),
      sectionNote: document.getElementById("section-note"),
      empty: document.getElementById("list-empty"),
      error: document.getElementById("list-error"),
      errorMessage: document.getElementById("error-message"),
      cardTemplate: document.getElementById("task-card-template"),
      heroProgress: document.getElementById("hero-progress"),
      heroProgressValue: document.getElementById("hero-progress-value"),
      statTotal: document.getElementById("stat-total"),
      statDoing: document.getElementById("stat-doing"),
      statDone: document.getElementById("stat-done"),
      heroHint: document.getElementById("hero-hint-text"),
      pulseNote: document.getElementById("pulse-note-text")
    };

    const state = {
      allTasks: [],
      status: "all",
      query: "",
      priority: "all",
      sort: "due",
      ready: false
    };

    hydrateFilters(state, elements);
    renderTabState(state, elements);
    bindListEvents(state, elements);

    elements.taskSection.setAttribute("aria-busy", "true");
    if (elements.loadingGrid) elements.loadingGrid.hidden = false;
    elements.create.disabled = true;

    loadTaskData()
      .then((tasks) => {
        state.allTasks = tasks;
        state.ready = true;
        if (elements.loadingGrid) elements.loadingGrid.hidden = true;
        elements.taskSection.setAttribute("aria-busy", "false");
        elements.create.disabled = false;
        updateStatusCounts(tasks, elements);
        updateOverview(tasks, elements);
        applyFilters(state, elements);
        showNoticeFromUrl(notice);
      })
      .catch((error) => {
        showListError(error, elements);
      });
  }
  // 职责：列表页初始化；先恢复 URL 中的筛选条件，再发起唯一一次请求，成功与失败分别进入对应渲染分支。

  function hydrateFilters(state, elements) {
    const params = new URLSearchParams(window.location.search);
    const status = params.get("status");
    const priority = params.get("priority");
    const sort = params.get("sort");
    const query = params.get("q");

    if (status && STATUS_META[status]) {
      state.status = status;
    }

    if (priority && (priority === "all" || PRIORITY_META[priority])) {
      state.priority = priority;
    }

    if (sort && SORTERS[sort]) {
      state.sort = sort;
    }

    if (query) {
      state.query = query.slice(0, 80);
    }

    elements.search.value = state.query;
    elements.priority.value = state.priority;
    elements.sort.value = state.sort;
  }
  // 职责：从查询字符串恢复筛选状态，使带参数的链接可以直接分享给他人。

  function bindListEvents(state, elements) {
    let searchTimer = 0;

    elements.form.addEventListener("submit", (event) => {
      event.preventDefault();
    });

    elements.tabs.forEach((button) => {
      button.addEventListener("click", () => {
        state.status = button.dataset.status;
        renderTabState(state, elements);
        applyFilters(state, elements);
      });
    });

    elements.search.addEventListener("input", () => {
      window.clearTimeout(searchTimer);
      searchTimer = window.setTimeout(() => {
        state.query = elements.search.value.trim();
        applyFilters(state, elements);
      }, 140);
    });

    elements.search.addEventListener("keydown", (event) => {
      if (event.key === "Escape" && elements.search.value) {
        elements.search.value = "";
        state.query = "";
        applyFilters(state, elements);
      }
    });

    elements.priority.addEventListener("change", () => {
      state.priority = elements.priority.value;
      applyFilters(state, elements);
    });

    elements.sort.addEventListener("change", () => {
      state.sort = elements.sort.value;
      applyFilters(state, elements);
    });

    elements.reset.addEventListener("click", () => resetFilters(state, elements));
    elements.emptyReset.addEventListener("click", () => resetFilters(state, elements));
    elements.create.addEventListener("click", () => handleCreateTask(state, elements));
    elements.emptyCreate.addEventListener("click", () => handleCreateTask(state, elements));
    elements.retry.addEventListener("click", () => window.location.reload());

    document.addEventListener("keydown", (event) => {
      const target = event.target;
      const isTyping =
        target instanceof HTMLElement &&
        (target.matches("input, textarea, select, button") || target.isContentEditable);

      if (document.querySelector("dialog[open]")) {
        return;
      }

      if (event.key !== "/" || event.ctrlKey || event.metaKey || event.altKey || isTyping) {
        return;
      }

      event.preventDefault();
      elements.search.focus();
    });
  }
  // 职责：绑定所有列表交互；状态按钮即时筛选，搜索做 140ms 防抖，并支持 Esc 清空与“/”聚焦搜索框。

  function resetFilters(state, elements) {
    state.status = "all";
    state.query = "";
    state.priority = "all";
    state.sort = "due";

    elements.search.value = "";
    elements.priority.value = "all";
    elements.sort.value = "due";

    renderTabState(state, elements);
    applyFilters(state, elements);
    elements.search.focus({ preventScroll: true });
  }
  // 职责：一次性恢复默认筛选条件，供工具条按钮与空状态按钮复用。

  function handleCreateTask(state, elements) {
    if (!state.ready) {
      return;
    }

    openTaskEditor(null, state.allTasks, (task, nextTasks, saved) => {
      state.allTasks = nextTasks;
      state.status = "all";
      state.query = "";
      state.priority = "all";
      elements.search.value = "";
      elements.priority.value = "all";

      renderTabState(state, elements);
      updateStatusCounts(nextTasks, elements);
      updateOverview(nextTasks, elements);
      applyFilters(state, elements);
      showToast(
        saved
          ? `已新建「${task.title}」`
          : "已新建，但浏览器未允许保存，刷新后会恢复。"
      );
    });
  }
  // 职责：列表页的新建入口；保存后清掉会挡住新任务的筛选条件，但保留用户当前选择的排序。

  function renderTabState(state, elements) {
    elements.tabs.forEach((button) => {
      button.setAttribute("aria-pressed", String(button.dataset.status === state.status));
    });
  }
  // 职责：把当前状态同步到按钮的 aria-pressed，视觉样式与读屏状态来自同一个数据源。

  function applyFilters(state, elements) {
    if (!state.ready) {
      return;
    }

    const query = state.query.toLocaleLowerCase("zh-CN");
    const filtered = state.allTasks.filter((task) => {
      const matchesStatus = state.status === "all" || task.status === state.status;
      const matchesPriority = state.priority === "all" || task.priority === state.priority;
      const haystack = [
        task.title,
        task.summary,
        task.category,
        task.owner,
        ...(Array.isArray(task.tags) ? task.tags : [])
      ]
        .join(" ")
        .toLocaleLowerCase("zh-CN");

      return matchesStatus && matchesPriority && (!query || haystack.includes(query));
    });

    filtered.sort(SORTERS[state.sort] || SORTERS.due);

    const cards = filtered.map((task, index) =>
      createTaskCard(task, index, elements.cardTemplate)
    );

    elements.taskGrid.replaceChildren(...cards);
    elements.taskGrid.hidden = filtered.length === 0;
    elements.empty.hidden = filtered.length !== 0;

    const isEmptyList = state.allTasks.length === 0;

    if (isEmptyList) {
      elements.emptyTitle.textContent = "清单还是空的";
      elements.emptyMessage.textContent = "新建第一件待办，从一件小事开始。";
      elements.emptyReset.hidden = true;
    } else {
      elements.emptyTitle.textContent = "没有找到匹配的待办";
      elements.emptyMessage.textContent = "换一个关键词，或者把筛选条件放宽一点。";
      elements.emptyReset.hidden = false;
    }

    elements.emptyCreate.hidden = false;

    const hasFilters =
      state.status !== "all" ||
      state.priority !== "all" ||
      Boolean(state.query) ||
      state.sort !== "due";

    elements.listTitle.textContent =
      state.status === "all" ? "全部待办" : STATUS_META[state.status].listTitle;
    elements.sectionNote.textContent = isEmptyList
      ? "还没有待办，先新建一件"
      : `共 ${state.allTasks.length} 件 · 按${SORT_META[state.sort]}排列`;
    elements.resultCount.textContent = isEmptyList
      ? "清单还是空的"
      : hasFilters
        ? `筛选出 ${filtered.length} 件，共 ${state.allTasks.length} 件`
        : `共 ${filtered.length} 件，按${SORT_META[state.sort]}排列`;

    syncFiltersToUrl(state);
  }
  // 职责：筛选与排序的唯一计算入口；组合状态、关键词、优先级三个条件后重绘卡片，并把结果同步到 URL。

  function updateStatusCounts(tasks, elements) {
    const counts = { all: tasks.length, todo: 0, doing: 0, done: 0 };

    tasks.forEach((task) => {
      if (Object.prototype.hasOwnProperty.call(counts, task.status)) {
        counts[task.status] += 1;
      }
    });

    elements.tabs.forEach((button) => {
      const count = button.querySelector("[data-count]");
      if (count) {
        count.textContent = String(counts[button.dataset.status] ?? 0);
      }
    });
  }
  // 职责：统计各状态数量，填充筛选按钮上的数字徽标。

  function updateOverview(tasks, elements) {
    const total = tasks.length;
    const done = tasks.filter((task) => task.status === "done").length;
    const doing = tasks.filter((task) => task.status === "doing").length;
    const percent = total === 0 ? 0 : Math.round((done / total) * 100);

    elements.heroProgress.style.setProperty("--progress", `${percent}%`);
    elements.heroProgress.setAttribute("aria-label", `今日任务完成进度：${percent}%`);
    elements.heroProgressValue.textContent = String(percent);
    elements.statTotal.textContent = String(total);
    elements.statDoing.textContent = String(doing);
    elements.statDone.textContent = String(done);

    if (total === 0) {
      elements.heroHint.textContent = "清单还是空的，先写下一件小事。";
      elements.pulseNote.textContent = "新建第一件待办，从最小的一步开始。";
      return;
    }

    elements.heroHint.textContent = `${total} 件待办，${doing} 件正在进行。按自己的节奏来。`;
    elements.pulseNote.textContent =
      done === total
        ? "今天的清单已经全部完成，去休息吧。"
        : `还有 ${Math.max(total - done, 0)} 件没有完成，挑一件开始就好。`;
  }
  // 职责：把任务统计映射到首屏进度环与数字；完成率由已完成数除以总数实时计算。

  function showListError(error, elements) {
    if (elements.loadingGrid) elements.loadingGrid.hidden = true;
    elements.taskGrid.hidden = true;
    elements.empty.hidden = true;
    elements.error.hidden = false;
    elements.errorMessage.textContent = `${error.message}。请确认 data/tasks.json 与页面处于同一站点。`;
    elements.resultCount.textContent = "清单加载失败";
    elements.listTitle.textContent = "暂时无法读取清单";
    elements.sectionNote.textContent = "数据请求未完成";
    elements.taskSection.setAttribute("aria-busy", "false");
    console.error("[拾光清单] 任务读取失败：", error);
  }
  // 职责：把 fetch 失败转换为可操作错误界面，并提示本地预览必须通过 HTTP 服务器打开。

  function syncFiltersToUrl(state) {
    const params = new URLSearchParams();

    if (state.status !== "all") {
      params.set("status", state.status);
    }

    if (state.query) {
      params.set("q", state.query);
    }

    if (state.priority !== "all") {
      params.set("priority", state.priority);
    }

    if (state.sort !== "due") {
      params.set("sort", state.sort);
    }

    const search = params.toString();
    const nextUrl = `${window.location.pathname}${search ? `?${search}` : ""}${window.location.hash}`;

    try {
      window.history.replaceState(null, "", nextUrl);
    } catch {
      /* 某些本地环境不允许修改历史记录，筛选功能本身不受影响。 */
    }
  }
  // 职责：把筛选条件写回地址栏但不新增历史记录；分享链接时即可还原同一视图。

  /* ------------------------------------------------------------------------
     共享渲染
     ------------------------------------------------------------------------ */

  function createTaskCard(task, index, template) {
    const fragment = template.content.cloneNode(true);
    const item = fragment.querySelector(".task-card__item");
    const card = fragment.querySelector(".task-card");
    const status = STATUS_META[task.status] || STATUS_META.todo;
    const priority = PRIORITY_META[task.priority] || PRIORITY_META.low;
    const checklist = getChecklist(task);
    const doneSteps = checklist.filter((item) => item.done).length;

    card.dataset.status = task.status;
    card.style.setProperty("--delay", `${Math.min(index, 9) * 45}ms`);

    const statusEl = card.querySelector("[data-task-status]");
    statusEl.classList.add(`status-pill--${STATUS_META[task.status] ? task.status : "todo"}`);
    statusEl.textContent = status.label;

    card.querySelector("[data-task-number]").textContent = String(index + 1).padStart(2, "0");
    card.querySelector("[data-task-category]").textContent = task.category;

    const priorityEl = card.querySelector("[data-task-priority]");
    priorityEl.classList.add(`priority-flag--${PRIORITY_META[task.priority] ? task.priority : "low"}`);
    priorityEl.textContent = priority.label;

    const link = card.querySelector("[data-task-link]");
    link.href = `./detail.html?id=${encodeURIComponent(task.id)}`;
    link.textContent = task.title;

    card.querySelector("[data-task-summary]").textContent = task.summary;

    const tagList = card.querySelector("[data-task-tags]");
    const tags = Array.isArray(task.tags) ? task.tags : [];

    if (tags.length > 0) {
      tagList.replaceChildren(
        ...tags.map((tag) => {
          const item = document.createElement("li");
          item.textContent = tag;
          return item;
        })
      );
    } else {
      tagList.hidden = true;
    }

    const progress = card.querySelector("[data-task-progress]");
    const progressBar = card.querySelector("[data-progress-bar]");
    const progressLabel = card.querySelector("[data-progress-label]");

    if (checklist.length > 0) {
      const percent = Math.round((doneSteps / checklist.length) * 100);
      progressBar.style.width = `${percent}%`;
      progressLabel.textContent = `${doneSteps}/${checklist.length} 步`;
      progress.setAttribute("aria-label", `已完成 ${doneSteps} / ${checklist.length} 步`);
    } else {
      progress.hidden = true;
    }

    const dueWrap = card.querySelector("[data-task-due-wrap]");
    const dueTime = card.querySelector("[data-task-due]");
    dueTime.dateTime = task.due || "";
    dueTime.textContent = formatDueLabel(task);

    if (isOverdue(task)) {
      dueWrap.classList.add("is-overdue");
    }

    card.querySelector("[data-task-owner]").textContent = task.owner;
    card.querySelector("[data-task-avatar]").textContent = String(task.owner || "?").trim().charAt(0);
    card.querySelector("[data-task-avatar]").style.background = avatarColor(task.owner);

    return item;
  }
  // 职责：克隆卡片模板并填入一条任务，返回合法的 li 列表项；所有文本使用 textContent，避免把 JSON 内容当作 HTML 执行。

  function avatarColor(name) {
    const palette = ["#20241f", "#6f8768", "#b94c2d", "#5f7488", "#846321"];
    const total = Array.from(String(name || "")).reduce((sum, char) => sum + char.codePointAt(0), 0);
    return palette[total % palette.length];
  }
  // 职责：根据负责人姓名生成稳定的头像底色，让同一人始终得到同一颜色。

  function setCurrentYear() {
    const year = String(new Date().getFullYear());
    document.querySelectorAll("[data-current-year]").forEach((element) => {
      element.textContent = year;
    });

    const heroYear = document.getElementById("hero-year");
    if (heroYear) {
      heroYear.textContent = year;
    }
  }
  // 职责：把页脚与进度卡里的年份更新为当前年份，避免静态页面跨年后显示过期。

  function setTodayLabel() {
    const label = document.getElementById("today-label");
    if (!label) {
      return;
    }

    const now = new Date();
    label.dateTime = toISODate(now);
    label.textContent = `${now.getFullYear()}年${now.getMonth() + 1}月${now.getDate()}日 · ${WEEKDAYS[now.getDay()]}`;
  }
  // 职责：在列表页生成带星期几的当天日期，使用本地时区，避免 toISOString 带来的时差偏移。

  /* ------------------------------------------------------------------------
     日期与勾选状态
     ------------------------------------------------------------------------ */

  function parseISODate(value) {
    if (!value || !/^\d{4}-\d{2}-\d{2}$/.test(value)) {
      return null;
    }

    const [year, month, day] = value.split("-").map(Number);
    return new Date(year, month - 1, day);
  }
  // 职责：把 YYYY-MM-DD 解析为本地日期对象；手动拆分可避免不同浏览器对日期字符串的时区差异。

  function toISODate(date) {
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    return `${date.getFullYear()}-${month}-${day}`;
  }
  // 职责：把 Date 转回 YYYY-MM-DD，供 time[datetime] 与筛选状态使用。

  function dayDifference(target) {
    const now = new Date();
    const todayUTC = Date.UTC(now.getFullYear(), now.getMonth(), now.getDate());
    const targetUTC = Date.UTC(target.getFullYear(), target.getMonth(), target.getDate());
    return Math.round((targetUTC - todayUTC) / 86400000);
  }
  // 职责：按“自然日”计算日期差，忽略具体时刻，避免 23:59 与 00:01 被误判为同一天。

  function isOverdue(task) {
    const due = parseISODate(task.due);
    return Boolean(due) && task.status !== "done" && dayDifference(due) < 0;
  }
  // 职责：判断未完成任务是否已逾期；已完成任务永远不再显示逾期。

  function formatDueLabel(task) {
    const due = parseISODate(task.due);

    if (!due) {
      return "未设置截止日期";
    }

    if (task.status === "done") {
      return `截止 ${due.getMonth() + 1}月${due.getDate()}日`;
    }

    const diff = dayDifference(due);

    if (diff < 0) {
      return `已逾期 ${Math.abs(diff)} 天`;
    }

    if (diff === 0) {
      return "今天截止";
    }

    if (diff === 1) {
      return "明天截止";
    }

    return `${due.getMonth() + 1}月${due.getDate()}日截止`;
  }
  // 职责：把截止日期转换为“今天截止 / 明天截止 / 已逾期 N 天”的易读文案。

  function formatFullDate(value) {
    const date = parseISODate(value);
    return date ? `${date.getFullYear()}年${date.getMonth() + 1}月${date.getDate()}日` : "未设置";
  }
  // 职责：详情页事实表使用的完整中文日期格式。

  function getChecklist(task) {
    const defaults = Array.isArray(task.checklist) ? task.checklist : [];
    const saved = readChecklist(task.id);

    return defaults.map((item, index) => ({
      text: String(item?.text ?? ""),
      done:
        saved && typeof saved[index] === "boolean"
          ? saved[index]
          : Boolean(item?.done)
    }));
  }
  // 职责：合并 JSON 里的默认勾选状态与 localStorage 中的本地修改，列表进度和详情页读取同一份结果。

  function readChecklist(taskId) {
    try {
      const raw = window.localStorage.getItem(`${CHECKLIST_PREFIX}${taskId}`);
      if (!raw) {
        return null;
      }

      const parsed = JSON.parse(raw);
      return parsed && typeof parsed === "object" ? parsed : null;
    } catch {
      return null;
    }
  }
  // 职责：安全读取单个任务的勾选记录；隐私模式或禁用存储时静默降级为 JSON 默认值。

  function saveChecklist(taskId, checklist) {
    const payload = {};

    checklist.forEach((item, index) => {
      payload[index] = item.done;
    });

    try {
      window.localStorage.setItem(`${CHECKLIST_PREFIX}${taskId}`, JSON.stringify(payload));
    } catch {
      /* 存储不可用时只影响“记住进度”，不影响当前页面交互。 */
    }
  }
  // 职责：把勾选结果按任务 id 写入 localStorage，实现无后端的本地持久化。

  function clearChecklist(taskId) {
    try {
      window.localStorage.removeItem(`${CHECKLIST_PREFIX}${taskId}`);
    } catch {
      /* 同 saveChecklist：存储失败不应打断页面。 */
    }
  }
  // 职责：清除指定任务的本地勾选记录，供详情页“重置勾选状态”按钮调用。

  /* ------------------------------------------------------------------------
     新增 / 编辑 / 删除
     ------------------------------------------------------------------------ */

  let toastTimer = 0;

  function makeElement(tag, className, text) {
    const element = document.createElement(tag);

    if (className) {
      element.className = className;
    }

    if (text !== undefined && text !== null) {
      element.textContent = text;
    }

    return element;
  }
  // 职责：用 DOM API 创建节点的小工具；全站动态内容都走 textContent，不拼接 HTML 字符串。

  function addEditorField(grid, config) {
    const field = makeElement("label", "editor-field");

    if (config.full) {
      field.classList.add("editor-field--full");
    }

    const label = makeElement("span", "editor-field__label", config.label);

    if (config.required) {
      const requiredMark = makeElement("span", "editor-field__required", " *");
      requiredMark.setAttribute("aria-hidden", "true");
      label.append(requiredMark);
    }

    field.append(label);

    let control;

    if (config.tag === "textarea") {
      control = makeElement("textarea");
      control.rows = config.rows || 3;
    } else if (config.tag === "select") {
      control = makeElement("select");
      config.options.forEach(([value, optionLabel]) => {
        const option = makeElement("option", "", optionLabel);
        option.value = value;
        control.append(option);
      });
    } else {
      control = makeElement("input");
      control.type = config.type || "text";
    }

    control.name = config.name;

    if (config.value !== undefined && config.value !== null) {
      control.value = String(config.value);
    }

    if (config.required) {
      control.required = true;
    }

    if (config.maxLength) {
      control.maxLength = config.maxLength;
    }

    if (config.placeholder) {
      control.placeholder = config.placeholder;
    }

    if (config.listId) {
      control.setAttribute("list", config.listId);
    }

    field.append(control);
    grid.append(field);
    return control;
  }
  // 职责：按字段配置生成“标签 + 原生控件”的一行；新增和编辑共用同一份表单结构。

  function openTaskEditor(task, tasks, onSaved) {
    const editing = Boolean(task);
    const existingChecklist = editing ? getChecklist(task) : [];
    const dialog = makeElement("dialog", "task-dialog");
    dialog.setAttribute("aria-labelledby", "task-dialog-title");

    const form = makeElement("form", "task-form");
    form.autocomplete = "off";

    const head = makeElement("header", "task-dialog__head");
    const eyebrow = makeElement("p", "eyebrow", editing ? "EDIT TASK" : "NEW TASK");
    const heading = makeElement("h2", "", editing ? "改写这件待办" : "新建一件待办");
    heading.id = "task-dialog-title";

    const closeButton = makeElement("button", "task-dialog__close", "×");
    closeButton.type = "button";
    closeButton.setAttribute("aria-label", "关闭编辑器");
    head.append(eyebrow, heading, closeButton);

    const lead = makeElement(
      "p",
      "task-dialog__lead",
      editing
        ? "改完点保存，清单和详情页会一起更新。"
        : "只写此刻最想记住的部分，剩下的可以之后慢慢补。"
    );
    lead.id = "task-dialog-lead";
    form.setAttribute("aria-describedby", lead.id);

    const body = makeElement("section", "task-form__body");
    body.setAttribute("aria-label", "待办内容");

    const grid = makeElement("fieldset", "editor-grid");
    const legend = makeElement("legend", "sr-only", "待办字段");
    grid.append(legend);

    const categories = Array.from(
      new Set(
        [
          ...tasks.map((item) => item.category),
          "生活",
          "工作",
          "创作",
          "学习",
          "家务",
          "健康"
        ].filter(Boolean)
      )
    ).slice(0, 10);
    const categoryOptions = makeElement("datalist");
    categoryOptions.id = "task-category-options";
    categories.forEach((value) => {
      const option = makeElement("option");
      option.value = value;
      categoryOptions.append(option);
    });

    const titleInput = addEditorField(grid, {
      label: "标题",
      name: "title",
      value: task?.title || "",
      required: true,
      full: true,
      maxLength: 60,
      placeholder: "例如：整理书桌"
    });

    addEditorField(grid, {
      label: "一句话摘要",
      name: "summary",
      tag: "textarea",
      rows: 2,
      value: task?.summary || "",
      full: true,
      maxLength: 120,
      placeholder: "用一句话说清这件待办"
    });

    addEditorField(grid, {
      label: "分类",
      name: "category",
      value: task?.category || "",
      maxLength: 20,
      placeholder: "生活 / 工作 / 学习",
      listId: categoryOptions.id
    });

    addEditorField(grid, {
      label: "负责人",
      name: "owner",
      value: task?.owner || "我",
      maxLength: 20,
      placeholder: "我"
    });

    addEditorField(grid, {
      label: "截止日期",
      name: "due",
      type: "date",
      value: task?.due || toISODate(new Date()),
      required: true
    });

    addEditorField(grid, {
      label: "状态",
      name: "status",
      tag: "select",
      value: task?.status || "todo",
      options: Object.entries(STATUS_META).map(([value, meta]) => [value, meta.label])
    });

    addEditorField(grid, {
      label: "优先级",
      name: "priority",
      tag: "select",
      value: task?.priority || "medium",
      options: Object.entries(PRIORITY_META).map(([value, meta]) => [value, meta.label])
    });

    addEditorField(grid, {
      label: "标签",
      name: "tags",
      value: Array.isArray(task?.tags) ? task.tags.join("，") : "",
      maxLength: 60,
      placeholder: "阅读，策划（最多 4 个）"
    });

    addEditorField(grid, {
      label: "任务说明",
      name: "description",
      tag: "textarea",
      rows: 3,
      value: Array.isArray(task?.description) ? task.description.join("\n") : "",
      full: true,
      maxLength: 600,
      placeholder: "每行一段，写下背景或完成标准"
    });

    const checklistInput = addEditorField(grid, {
      label: "完成步骤",
      name: "checklist",
      tag: "textarea",
      rows: 4,
      value: existingChecklist.map((item) => item.text).join("\n"),
      full: true,
      maxLength: 600,
      placeholder: "每行一步，最多 8 步"
    });

    addEditorField(grid, {
      label: "给自己的话",
      name: "note",
      tag: "textarea",
      rows: 2,
      value: task?.note || "",
      full: true,
      maxLength: 160,
      placeholder: "写一句提醒，比如：先做五分钟"
    });

    const error = makeElement("p", "editor-error");
    error.hidden = true;
    error.setAttribute("role", "alert");
    body.append(grid, categoryOptions, error);

    const foot = makeElement("footer", "task-dialog__foot");
    const cancelButton = makeElement("button", "button button--quiet", "取消");
    cancelButton.type = "button";
    const saveButton = makeElement(
      "button",
      "button button--dark",
      editing ? "保存修改" : "加入清单"
    );
    saveButton.type = "submit";
    foot.append(cancelButton, saveButton);

    form.append(head, lead, body, foot);
    dialog.append(form);

    const closeDialog = () => {
      if (dialog.open) {
        dialog.close();
      }
    };

    closeButton.addEventListener("click", closeDialog);
    cancelButton.addEventListener("click", closeDialog);
    dialog.addEventListener("click", (event) => {
      if (event.target === dialog) {
        closeDialog();
      }
    });
    dialog.addEventListener("close", () => dialog.remove());

    form.addEventListener("submit", (event) => {
      event.preventDefault();
      error.hidden = true;
      error.textContent = "";

      const draft = buildTaskFromForm(
        form,
        editing ? task : null,
        tasks,
        error,
        checklistInput
      );

      if (!draft) {
        return;
      }

      const nextTasks = editing
        ? tasks.map((item) => (item.id === task.id ? draft : item))
        : [...tasks, draft];
      const saved = persistTasks(nextTasks);

      saveChecklist(draft.id, draft.checklist);
      dialog.close(saved ? "saved" : "unsaved");

      if (typeof onSaved === "function") {
        onSaved(draft, nextTasks, saved);
      }
    });

    document.body.append(dialog);
    dialog.showModal();
    titleInput.focus();

    if (editing) {
      titleInput.setSelectionRange(0, titleInput.value.length);
    }
  }
  // 职责：打开新增/编辑对话框；提交时先校验、再生成新任务、写 localStorage，最后交给调用方刷新界面。

  function buildTaskFromForm(form, existing, tasks, error, checklistInput) {
    const data = new FormData(form);
    const valueOf = (name) => String(data.get(name) ?? "").trim();
    const title = valueOf("title");

    if (!title) {
      showEditorError(error, "请先给这件待办写一个标题。", form.elements.title);
      return null;
    }

    const due = valueOf("due");

    if (!isISODateString(due)) {
      showEditorError(error, "请选择有效的截止日期。", form.elements.due);
      return null;
    }

    const description = splitLines(valueOf("description"));

    if (description.length > 6) {
      showEditorError(error, "任务说明最多写 6 段，请合并一些内容。", form.elements.description);
      return null;
    }

    const steps = splitLines(valueOf("checklist"));

    if (steps.length > 8) {
      showEditorError(error, "完成步骤最多 8 条，请删减一些。", checklistInput);
      return null;
    }

    const tags = splitTags(valueOf("tags"));

    if (tags.length > 4) {
      showEditorError(error, "标签最多保留 4 个。", form.elements.tags);
      return null;
    }

    const statusValue = valueOf("status");
    const priorityValue = valueOf("priority");
    const doneByText = new Map(
      (existing ? getChecklist(existing) : []).map((item) => [item.text, item.done])
    );

    return {
      id: existing?.id || createTaskId(title, tasks),
      title,
      summary: valueOf("summary") || "还没有写摘要。",
      description,
      checklist: steps.map((text) => ({
        text,
        done: Boolean(doneByText.get(text))
      })),
      note: valueOf("note"),
      status: STATUS_META[statusValue] ? statusValue : "todo",
      priority: PRIORITY_META[priorityValue] ? priorityValue : "medium",
      category: valueOf("category") || "未分类",
      owner: valueOf("owner") || "我",
      tags,
      due,
      updated: toISODate(new Date())
    };
  }
  // 职责：从原生 FormData 构建一条完整任务；编辑时按步骤文字保留原来的勾选状态，避免覆盖详情页进度。

  function splitLines(value) {
    return String(value ?? "")
      .split(/\r?\n/)
      .map((line) => line.trim())
      .filter(Boolean);
  }
  // 职责：把多行文本切成干净数组，供任务说明与完成步骤复用。

  function splitTags(value) {
    return Array.from(
      new Set(
        String(value ?? "")
          .split(/[,，、]/)
          .map((tag) => tag.trim())
          .filter(Boolean)
      )
    );
  }
  // 职责：支持中英文逗号和顿号分隔标签，并自动去重。

  function showEditorError(error, message, control) {
    error.textContent = message;
    error.hidden = false;

    if (control instanceof HTMLElement) {
      control.focus();
    }
  }
  // 职责：把校验失败原因放到表单内的 role="alert" 区域，并把焦点送回对应控件。

  function showToast(message) {
    let toast = document.getElementById("site-toast");

    if (!toast) {
      toast = makeElement("p", "toast");
      toast.id = "site-toast";
      toast.setAttribute("role", "status");
      toast.setAttribute("aria-live", "polite");
      toast.setAttribute("aria-atomic", "true");
      toast.hidden = true;
      document.body.append(toast);
    }

    toast.textContent = message;
    toast.hidden = false;
    window.clearTimeout(toastTimer);
    window.requestAnimationFrame(() => toast.classList.add("is-visible"));

    toastTimer = window.setTimeout(() => {
      toast.classList.remove("is-visible");
      window.setTimeout(() => {
        if (!toast.classList.contains("is-visible")) {
          toast.hidden = true;
        }
      }, 200);
    }, 3200);
  }
  // 职责：保存、删除、新建后的轻量反馈；用 aria-live 让读屏器也能收到结果。

  function showNoticeFromUrl(notice) {
    const messages = {
      deleted: "待办已删除，清单已更新。"
    };

    if (notice && messages[notice]) {
      showToast(messages[notice]);
    }
  }
  // 职责：详情页删除后跳回列表时显示一次结果提示；提示参数会被 syncFiltersToUrl 从地址栏清掉。

  function confirmTaskDelete(task, onConfirm) {
    const dialog = makeElement("dialog", "confirm-dialog");
    dialog.setAttribute("aria-labelledby", "confirm-dialog-title");

    const card = makeElement("section", "confirm-card");
    const eyebrow = makeElement("p", "eyebrow", "DELETE TASK");
    const heading = makeElement("h2", "", "删除这件待办？");
    heading.id = "confirm-dialog-title";
    const description = makeElement(
      "p",
      "",
      `「${task.title}」只会从这台浏览器移除，删除后无法撤销。`
    );
    description.id = "confirm-dialog-text";
    dialog.setAttribute("aria-describedby", description.id);

    const actions = makeElement("footer", "confirm-card__actions");
    const cancelButton = makeElement("button", "button button--quiet", "取消");
    cancelButton.type = "button";
    const deleteButton = makeElement("button", "button button--danger-solid", "删除");
    deleteButton.type = "button";
    actions.append(cancelButton, deleteButton);
    card.append(eyebrow, heading, description, actions);
    dialog.append(card);

    const closeDialog = () => {
      if (dialog.open) {
        dialog.close();
      }
    };

    cancelButton.addEventListener("click", closeDialog);
    deleteButton.addEventListener("click", () => {
      dialog.close("confirmed");
      if (typeof onConfirm === "function") {
        onConfirm();
      }
    });
    dialog.addEventListener("click", (event) => {
      if (event.target === dialog) {
        closeDialog();
      }
    });
    dialog.addEventListener("close", () => dialog.remove());

    document.body.append(dialog);
    dialog.showModal();
    cancelButton.focus();
  }
  // 职责：自定义删除确认框；默认聚焦“取消”，避免误按键盘直接删除。

  /* ------------------------------------------------------------------------
     详情页
     ------------------------------------------------------------------------ */

  function initDetailPage() {
    setCurrentYear();

    const root = document.getElementById("detail-root");
    const detailTemplate = document.getElementById("detail-template");
    const cardTemplate = document.getElementById("task-card-template");
    const taskId = new URLSearchParams(window.location.search).get("id");

    if (!taskId) {
      renderDetailState(root, {
        mark: "?",
        eyebrow: "NO TASK SELECTED",
        title: "还没有选择要查看的待办",
        message: "回到全部清单，挑一件想了解的待办再打开详情。"
      });
      return;
    }

    loadTaskData()
      .then((tasks) => {
        const task = tasks.find((item) => item.id === taskId);

        if (!task) {
          renderDetailState(root, {
            mark: "?",
            eyebrow: "TASK NOT FOUND",
            title: "这件待办不存在",
            message: "它可能已经从清单中被移除。回到列表页看看其他待办吧。"
          });
          return;
        }

        renderDetail(task, tasks, root, detailTemplate, cardTemplate);
      })
      .catch((error) => {
        console.error("[拾光清单] 详情读取失败：", error);
        renderDetailState(root, {
          mark: "!",
          eyebrow: "SOMETHING WENT WRONG",
          title: "详情暂时打不开",
          message: `${error.message}。请确认 data/tasks.json 可访问后再刷新页面。`
        });
      });
  }
  // 职责：详情页入口；解析 id、复用同一次数据请求、处理缺失 id / 找不到任务 / 请求失败三种异常。

  function renderDetail(task, tasks, root, detailTemplate, cardTemplate) {
    const fragment = detailTemplate.content.cloneNode(true);
    const article = fragment.querySelector(".detail");
    const status = STATUS_META[task.status] || STATUS_META.todo;
    const priority = PRIORITY_META[task.priority] || PRIORITY_META.low;

    const statusEl = article.querySelector("[data-detail-status]");
    statusEl.classList.add(`status-pill--${STATUS_META[task.status] ? task.status : "todo"}`);
    statusEl.textContent = status.label;

    article.querySelector("[data-detail-category]").textContent = task.category;

    const priorityEl = article.querySelector("[data-detail-priority]");
    priorityEl.classList.add(`priority-flag--${PRIORITY_META[task.priority] ? task.priority : "low"}`);
    priorityEl.textContent = priority.label;

    article.querySelector("[data-detail-title]").textContent = task.title;
    article.querySelector("[data-detail-summary]").textContent = task.summary;
    article.querySelector("[data-detail-owner]").textContent = task.owner;
    article.querySelector("[data-detail-category-text]").textContent = task.category;

    const dueTime = article.querySelector("[data-detail-due]");
    dueTime.dateTime = task.due || "";
    dueTime.textContent = formatFullDate(task.due);

    const updatedTime = article.querySelector("[data-detail-updated]");
    updatedTime.dateTime = task.updated || "";
    updatedTime.textContent = formatFullDate(task.updated);

    const description = article.querySelector("[data-detail-description]");
    const paragraphs = (Array.isArray(task.description) ? task.description : []).map((text) => {
      const paragraph = document.createElement("p");
      paragraph.textContent = text;
      return paragraph;
    });

    if (paragraphs.length === 0) {
      const fallback = document.createElement("p");
      fallback.textContent = "这件待办还没有补充说明。先从最小的一步开始吧。";
      paragraphs.push(fallback);
    }

    description.replaceChildren(...paragraphs);

    article.querySelector("[data-detail-note]").textContent =
      task.note || "先做五分钟，剩下的会自己长出来。";

    article.querySelector("[data-aside-status]").textContent = status.label;
    article.querySelector("[data-aside-priority]").textContent = priority.label;
    article.querySelector("[data-aside-id]").textContent = `#${task.id}`;

    const checklistList = article.querySelector("[data-checklist]");
    const progress = article.querySelector("[data-check-progress]");
    const count = article.querySelector("[data-check-count]");
    const resetButton = article.querySelector("[data-reset-checks]");
    let checklist = getChecklist(task);

    renderChecklist(checklistList, checklist);
    updateChecklistProgress(progress, count, checklist);

    checklistList.addEventListener("change", (event) => {
      const input = event.target;

      if (!(input instanceof HTMLInputElement) || input.type !== "checkbox") {
        return;
      }

      const index = Number(input.dataset.index);
      if (!Number.isInteger(index) || !checklist[index]) {
        return;
      }

      checklist[index].done = input.checked;
      input.closest("li")?.classList.toggle("is-done", input.checked);
      saveChecklist(task.id, checklist);
      updateChecklistProgress(progress, count, checklist);
    });

    resetButton.addEventListener("click", () => {
      clearChecklist(task.id);
      checklist = getChecklist(task);
      renderChecklist(checklistList, checklist);
      updateChecklistProgress(progress, count, checklist);
    });

    article.querySelector("[data-edit-task]").addEventListener("click", () => {
      openTaskEditor(task, tasks, (updated, nextTasks, saved) => {
        renderDetail(updated, nextTasks, root, detailTemplate, cardTemplate);
        root.closest("dialog")?.setAttribute("data-changed", "true");
        const heading = root.querySelector("[data-detail-title]");
        heading?.focus({ preventScroll: true });
        showToast(
          saved
            ? "修改已保存。"
            : "修改已生效，但浏览器未允许保存，刷新后会恢复。"
        );
      });
    });

    article.querySelector("[data-delete-task]").addEventListener("click", () => {
      confirmTaskDelete(task, () => {
        const nextTasks = tasks.filter((item) => item.id !== task.id);

        if (!persistTasks(nextTasks)) {
          showToast("浏览器未允许保存，删除未完成。请检查存储权限后重试。");
          return;
        }

        clearChecklist(task.id);

        // 单文件离线版的详情是页内弹层；删除后关闭弹层并重新读取本机数据。
        if (window.__DAYMARK_STANDALONE__ && root.closest("dialog")) {
          root.closest("dialog").close();
          window.location.reload();
          return;
        }

        window.location.href = "./index.html?notice=deleted";
      });
    });

    const relatedList = article.querySelector("[data-related]");
    const related = pickRelatedTasks(task, tasks);

    if (related.length > 0) {
      relatedList.replaceChildren(
        ...related.map((item, index) => createTaskCard(item, index, cardTemplate))
      );
    } else {
      article.querySelector(".related").hidden = true;
    }

    root.replaceChildren(article);
    root.setAttribute("aria-busy", "false");
    document.title = `${task.title} · 拾光清单`;
  }
  // 职责：用模板填充详情页全部内容、绑定勾选进度与重置按钮，并在同一批数据中挑选相关任务。

  function renderChecklist(list, checklist) {
    const items = checklist.map((item, index) => {
      const listItem = document.createElement("li");
      const label = document.createElement("label");
      const input = document.createElement("input");
      const text = document.createElement("span");

      input.type = "checkbox";
      input.checked = item.done;
      input.dataset.index = String(index);
      text.className = "checklist__text";
      text.textContent = item.text;

      if (item.done) {
        listItem.classList.add("is-done");
      }

      label.append(input, text);
      listItem.append(label);
      return listItem;
    });

    list.replaceChildren(...items);
  }
  // 职责：根据勾选数组重建步骤列表；使用 label 包裹原生 checkbox，点击整行与键盘操作都可用。

  function updateChecklistProgress(progress, count, checklist) {
    const total = checklist.length;
    const done = checklist.filter((item) => item.done).length;
    const percent = total === 0 ? 0 : Math.round((done / total) * 100);

    progress.max = Math.max(total, 1);
    progress.value = done;
    progress.textContent = `${percent}%`;
    progress.setAttribute("aria-label", `清单完成进度：${done} / ${total} 步`);
    count.textContent = `${done} / ${total}`;
  }
  // 职责：同步原生 progress 元素与文字计数，读屏器可从 aria-label 获得准确的完成步数。

  function pickRelatedTasks(current, tasks) {
    return tasks
      .filter((task) => task.id !== current.id)
      .slice()
      .sort((a, b) => {
        const score = (task) =>
          (task.category === current.category ? 0 : 2) + (task.status === "done" ? 1 : 0);
        return score(a) - score(b) || String(a.due).localeCompare(String(b.due));
      })
      .slice(0, 3);
  }
  // 职责：优先推荐同分类、未完成且截止更近的任务，最多展示三件，不产生额外请求。

  function renderDetailState(root, { mark, eyebrow, title, message }) {
    const section = document.createElement("section");
    const markEl = document.createElement("p");
    const eyebrowEl = document.createElement("p");
    const heading = document.createElement("h1");
    const description = document.createElement("p");
    const back = document.createElement("a");

    section.className = "detail-state";
    markEl.className = "detail-state__mark";
    markEl.setAttribute("aria-hidden", "true");
    markEl.textContent = mark;
    eyebrowEl.className = "eyebrow";
    eyebrowEl.textContent = eyebrow;
    heading.textContent = title;
    description.textContent = message;
    back.className = "button button--dark";
    back.href = "./index.html";
    back.textContent = "← 回到全部清单";

    section.append(markEl, eyebrowEl, heading, description, back);
    root.replaceChildren(section);
    root.setAttribute("aria-busy", "false");
  }
  // 职责：统一渲染缺失参数、找不到任务与加载失败三种详情异常状态，始终提供返回清单的出口。

  /* ------------------------------------------------------------------------
     单文件离线版：详情改用页内 <dialog>，不发新请求
     ------------------------------------------------------------------------ */

  function openStandaloneDetail(taskId) {
    const dialog = document.getElementById("standalone-detail-dialog");
    const root = document.getElementById("standalone-detail-root");
    const detailTemplate = document.getElementById("detail-template");
    const cardTemplate = document.getElementById("task-card-template");

    if (!dialog || !root || !detailTemplate || !cardTemplate) {
      return;
    }

    if (!dialog.open) {
      dialog.removeAttribute("data-changed");
    }

    root.setAttribute("aria-busy", "true");

    loadTaskData()
      .then((tasks) => {
        const task = tasks.find((item) => item.id === taskId);

        if (!task) {
          showToast("这件待办已经不在清单里。");
          return;
        }

        renderDetail(task, tasks, root, detailTemplate, cardTemplate);

        if (!dialog.open) {
          if (typeof dialog.showModal === "function") {
            dialog.showModal();
          } else {
            dialog.setAttribute("open", "");
          }
        }

        // 把焦点放到详情标题上，避免打开弹层时先给“关闭详情”套一圈醒目的焦点框。
        root.querySelector("[data-detail-title]")?.focus({ preventScroll: true });
      })
      .catch((error) => {
        console.error("[拾光清单] 详情读取失败：", error);
        showToast("详情暂时打不开，请刷新页面后再试。");
      });
  }

  function initStandaloneDetail() {
    const dialog = document.getElementById("standalone-detail-dialog");

    if (!dialog) {
      return;
    }

    const baseTitle = document.title;

    dialog.addEventListener("close", () => {
      document.title = baseTitle;

      // 编辑后关闭弹层时重新载入，让背后的列表同步显示新标题/状态。
      if (dialog.dataset.changed === "true") {
        dialog.removeAttribute("data-changed");
        window.location.reload();
      }
    });

    dialog.addEventListener("click", (event) => {
      if (event.target !== dialog) {
        return;
      }

      const rect = dialog.getBoundingClientRect();
      const outside =
        event.clientX < rect.left ||
        event.clientX > rect.right ||
        event.clientY < rect.top ||
        event.clientY > rect.bottom;

      if (outside) {
        dialog.close();
      }
    });

    document.addEventListener("click", (event) => {
      const link = event.target.closest?.("[data-task-link]");

      if (!link) {
        return;
      }

      const href = link.getAttribute("href") || "";

      if (!href.includes("detail.html")) {
        return;
      }

      event.preventDefault();

      const id = new URL(href, window.location.href).searchParams.get("id");

      if (id) {
        openStandaloneDetail(id);
      }
    });
  }

  if (window.__DAYMARK_STANDALONE__) {
    initStandaloneDetail();
  }
})();
